package Graph.basic;

public class Edge {
	public int s,e;
	public int weight;
	public Edge()
	{
		s=e=weight= 0;
	}
	public Edge(int s,int e, int weight)
	{
		this.s = s;
		this.e = e;
		this.weight = weight;
	}
	
	
}
