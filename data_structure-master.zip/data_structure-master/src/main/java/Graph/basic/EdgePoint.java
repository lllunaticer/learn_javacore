package Graph.basic;
//describe the weight of edge
public class EdgePoint {
	public int index;
	public int weight;
	public EdgePoint next = null;
}
