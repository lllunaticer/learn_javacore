package Sort.RadixSort;

/**
 * Created by chenxi on 15/4/29.
 */
public class Node {
    public int value;
    public Node next;
    public Node(int value)
    {
        this.value = value;
        this.next = null;
    }
}
