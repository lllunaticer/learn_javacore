大话数据结构JAVA版本源代码，优化无止境，掌握基础才能起飞

#Configuration
开发IDE : Intellij14
JDK: 1.8
项目管理工具: Maven


#Install
Install Maven, http://maven.apache.org/download.cgi

#Run
mvn package 然后就能补齐所有的包
可以导入IDE 能直接运行


#Test
应用代码在 test 文件夹下


